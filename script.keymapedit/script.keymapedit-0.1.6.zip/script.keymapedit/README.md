

# Keymap edit

A fork of Keymap Editor (https://github.com/tamland/xbmc-keymap-editor)

Changes so far:

- Added some missing actions introduced in Kodi v17 & v18

- Re-organised windows/actions

- Generated .xml is now properly indented, instead of 1 line

- Fixed keymap reloading after save

- Converted to current language formatting

- Added Greek language

- Pyhton 3/Kodi 19+ compatibility

- Added longpress function support
