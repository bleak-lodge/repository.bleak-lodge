# -*- coding: utf-8 -*-

from .simple_imdb import _get_imdb_trailers
